package com.sdm.JobApp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobApp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
